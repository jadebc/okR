import json
import sys
import requests

with open(sys.argv[1]) as data_file:
    scores = json.load(data_file)

total_score = 0

for problem in scores:
    total_score += scores[problem]
    print(scores[problem])

scores["Total Score"] = total_score
print(scores)

# data = {
#     'bid': 'aF249e',  # how to get this backup ID???
#     'score': 2.0,
#     'kind': 'Total',
#     'message': 'Test Output:\nTest 1: 2/2.\nGreat Work!'
# }
# url = 'https://okpy.org/api/v3/score/?access_token={}'
# access_token = 'test' # how to get current user access_token??
# r = requests.post(url.format(access_token), data=data)
# response = r.json())
