# Install necessary packages for OkR

install.packages("here", repos='http://cran.us.r-project.org')
install.packages("evaluate", repos='http://cran.us.r-project.org')
install.packages("jsonlite", repos='http://cran.us.r-project.org')
install.packages("checkr", repos='http://cran.us.r-project.org')
install.packages("assertthat", repos='http://cran.us.r-project.org')
install.packages("nycflights13", repos='http://cran.us.r-project.org')